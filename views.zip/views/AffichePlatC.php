<?php
include "../controller/platC.php";

	$platC=new platC();
	$listePlats=$platC->afficherPlat();

?>